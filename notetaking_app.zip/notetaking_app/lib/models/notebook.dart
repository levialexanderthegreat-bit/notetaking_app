class Notebook {
  final String title;
  final List<PageModel> pages;

  Notebook({required this.title, this.pages = const []});
}