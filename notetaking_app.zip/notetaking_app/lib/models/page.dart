class PageModel {
  final int number;
  final String? content;

  PageModel({required this.number, this.content});
}